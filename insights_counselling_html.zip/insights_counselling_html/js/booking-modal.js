document.addEventListener('DOMContentLoaded', () => {
    // 1. Create Modal HTML Structure
    const modalHTML = `
    <div id="booking-modal-overlay" class="booking-modal-overlay">
        <div class="booking-modal-container">
            <button id="booking-modal-close" class="booking-modal-close">&times;</button>
            <div class="booking-modal-loader" id="booking-modal-loader">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
            <iframe id="booking-modal-iframe" class="booking-modal-iframe" src="about:blank" frameborder="0"></iframe>
        </div>
    </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);

    const overlay = document.getElementById('booking-modal-overlay');
    const closeBtn = document.getElementById('booking-modal-close');
    const iframe = document.getElementById('booking-modal-iframe');
    const loader = document.getElementById('booking-modal-loader');

    // 2. Open Modal Function
    window.openBookingModal = function(url = '/bookings/') {
        // Prevent scrolling on body
        document.body.style.overflow = 'hidden';
        
        // Show overlay
        overlay.classList.add('active');
        loader.style.display = 'flex';
        
        // Load iframe
        iframe.src = url;
        
        iframe.onload = () => {
            loader.style.display = 'none';
        };
    };

    // 3. Close Modal Function
    window.closeBookingModal = function() {
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        setTimeout(() => {
            iframe.src = 'about:blank'; // Clear iframe to stop processes
        }, 300); // Wait for transition
    };

    // 4. Event Listeners
    closeBtn.addEventListener('click', closeBookingModal);

    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            closeBookingModal();
        }
    });

    // Handle Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && overlay.classList.contains('active')) {
            closeBookingModal();
        }
    });

    // 5. Attach to CTA buttons
    const bookingButtons = document.querySelectorAll('.btn-book-modal');
    bookingButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Check if it's explicitly set to redirect, otherwise use modal
            if (btn.dataset.bookingType === 'redirect') {
                return; // Let the normal href work
            }
            e.preventDefault();
            // Support specific service or agent params
            const serviceId = btn.dataset.serviceId;
            const agentId = btn.dataset.agentId;
            let url = '/bookings/';
            
            if (serviceId || agentId) {
                url += '?';
                if (serviceId) url += `service_id=${serviceId}&`;
                if (agentId) url += `agent_id=${agentId}`;
            }
            
            openBookingModal(url);
        });
    });
    
    // Add message listener for LatePoint to close modal
    window.addEventListener('message', function(event) {
        // Adjust the origin check as needed
        if (event.data === 'latepoint_booking_completed' || event.data === 'close_booking_modal') {
            closeBookingModal();
        }
    });
});
